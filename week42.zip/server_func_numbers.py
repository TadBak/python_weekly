def numbers():
    """Returns a list of 10 integers from 0 to 9.

    This function does not accept any arguments.
    """
    return list(range(10))

