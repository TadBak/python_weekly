"""Simple TCP client."""

import socket
import sys

SERVER = '127.0.0.1'    # server's IP address
PORT = 9999             # server's port
BUFSIZE = 1024          # size of the buffer for received data


def run(addr, port):
    """Runs the client and displays server's responses.

    The client sends commands to the server and displays responses, it terminates
    upon the 'bye' command. Because the server is capable of serving only one
    client at a time, the client make sure first that it has server's attention.
    """

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(3)     # 3 seconds timeout

    # context manager will close an opened socket on exit
    with sock:
        try:
            sock.connect((addr, port))
        except ConnectionRefusedError:
            print('Can not connect to the server')
            sys.exit(0)
        try:
            print(f'{sock.recv(BUFSIZE).decode()}')
        except socket.timeout:
            print('Server is busy')
            sys.exit(0)
        # after receiving initial server's message the client knows that
        # connection has been established, assumes timeout not needed now
        sock.settimeout(None)
        # handling client - server exchanges
        while True:
            send = input('SENT: ')
            sock.sendall(send.encode())
            print(f'RECEIVED: {sock.recv(BUFSIZE).decode()}')
            if send == 'bye':
                break


if __name__ == '__main__':
    run(SERVER, PORT)

