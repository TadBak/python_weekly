"""Simple TCP server with dynamically loaded functions."""

import socket
import glob
import re

PORT = 9999
BUFSIZE = 1024
# dictionary for storing functions' code read from the files
cmds = dict()
server_socket = None


def parse_to_dict(filename):
    """Scans the Python file and extracts all defined functions.

    The file is given by the filename, this function scans its contents and
    extracts Python code for all functions defined within. The code for each
    function is stored as a value in the global dictionary cmds, where the key
    is the name of the function. It is assumed that the names of all functions
    defined inside scanned files are unique.
    """

    with open(filename, 'r') as fn:
        txt = fn.read()
    # split the contents of the file into functions, assuming that only
    # functions' definitions are present inside
    code = ['def ' + chunk for chunk in txt.split('def ')[1:]]
    for func in code:
        # matches first occurence of the word 'def' followed by one or more
        # spaces, then any characters up to opening bracket (
        m = re.search(r'def +(.+)\(', func)
        # the captured group is the name of the function
        cmds[m.group(1)] = func


def get_description(code):
    """Returns the function's description extracted from its code.

    It is assumed that the first line of function's doctring contains 
    a meaningful description. If the docstring is absent this function
    returns an empty string.
    """

    # matches everything between triple quotes, including quotes, the actual
    # docstring is in the captured group
    m = re.search(r'"""(.+)"""', code, re.DOTALL)
    if m is None:
        return ''
    else:
        # only the first line of the doctring
        return m.group(1).split('\n')[0].strip()


def get_args_number(code):
    """Returns the expected number of function's arguments."""

    # matches first occurence of brackets ( ) and everything within, arguments
    # are stored in the captured group
    m = re.search(r'\((.*)\)', code)
    return len([item for item in m.group(1).split(',') if item])


def run(port):
    """Runs the server and handles messages received from the client.

    The server is supposed to run indefinitely, however it is not detached
    from its controlling terminal and can be stopped by pressing Ctrl-C.
    """

    for one_file in glob.glob('server_func_*.py'):
        parse_to_dict(one_file)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((socket.gethostbyname('localhost'), port))
    server_socket.listen()
    print('Server started')
    # after the client disconnets the new one can be served
    while True:
        conn, addr = server_socket.accept()
        # context manager assures that socket will be closed when finished
        with conn:
            print(f'Accepted connection from {addr[0]} on port {addr[1]}')
            # send to the client list of avilable commands
            info = ['\t' + key + f'\n{get_description(value)}\n' +
                    f'Expected number of arguments: {get_args_number(value)}\n'
                    for key, value in cmds.items()]
            info.append('\tbye\nTerminates connection with the server\n')
            msg = ('Connected, available commands:\n\n' + '\n'.join(info) +
                   '\nServer is listening...')
            conn.sendall(msg.encode()) 
            # handling client - server exchanges 
            while True:
                # command and its arguments, if any
                received = conn.recv(BUFSIZE).decode()
                if not received:
                    print('Client has crashed')
                    break
                command, *data = received.split()
                if command in cmds:
                    if len(data) == get_args_number(cmds[command]):
                        # dictionary for storing local variables
                        loc = dict()
                        exec(cmds[command], {}, loc)
                        # exec always returns None, but after loading the code
                        # for a function that function object is accessible via
                        # loc dictionary and can be executed
                        conn.sendall(str(loc[command](*data)).encode())
                    else:
                        conn.sendall('Wrong number of arguments'.encode())
                elif command == 'bye':
                    print('Client has disconnected')
                    conn.sendall('Bye!'.encode())
                    break
                else:
                    conn.sendall(f'Unknown function: {command}'.encode())
            

if __name__ == '__main__':
    try:
        run(PORT)
    except KeyboardInterrupt:
        if server_socket:
            server_socket.close()
        print('\nGood bye!')



